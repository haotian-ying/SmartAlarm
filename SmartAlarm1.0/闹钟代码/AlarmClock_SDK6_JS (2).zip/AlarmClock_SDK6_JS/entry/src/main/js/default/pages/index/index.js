/*index.js*/
import router from '@system.router'
// import fetch from '@system.fetch';
export default {
    data: {
        title: 'Alarm'
    },
    clickAction(){
        //        console.log("我被点击了")
        router.replace({
            uri:'pages/time/time',
        });
        // fetch.fetch({
        //     url:`https://qqlykm.cn/api/api/tq.php?city=北京`,
        //     responseType:"json",
        //     success:(resp)=>
        //     {
        //         this.winfo = resp.data;
        //     }
        // })
    }
}
