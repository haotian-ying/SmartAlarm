import router from '@system.router';
export default {
    data: {
        buttonInfo: "删除闹钟",
        weekImgSrcOn: 'common/ic_clock_btn_on.png',
        weekImgSrcOff: 'common/ic_clock_btn_off.png',
        Weeks:[
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'日'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'一'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'二'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'三'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'四'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'五'},
            {weekImg:'common/ic_clock_btn_off.png',weekOn:false,week:'六'}
        ],
        dataWrapper: {
            mode: "",
            time: "00:00",
            repeat: "不重复",
            switchStatus:false,
            alarmItemIndex: -1
        },
        targetHour: "00",
        targetMinute: "00",
        targeRepeat: '不重复',
        originData:[]
    },
    //初始化
    onInit(){
        //判断是新增还是修改
        if (this.dataWrapper.mode === "addAlarm") {
            this.buttonInfo = "取消";
        }
        //如果是修改要还原数据
        if (this.dataWrapper.mode === "editAlarm") {
            for (var i = 0; i < this.Weeks.length; i++) {
                if (this.dataWrapper.repeat.indexOf(this.Weeks[i].week) !== -1) {
                    this.Weeks[i].weekOn = true;
                    this.Weeks[i].weekImg = this.weekImgSrcOn;
                }
            }
        }
    },
    //选择星期
    changeWeekSelected(index) {
        this.Weeks[index].weekOn = this.Weeks[index].weekOn? false : true;
        this.Weeks[index].weekImg = this.Weeks[index].weekOn? this.weekImgSrcOn : this.weekImgSrcOff;
    },
    //选择时间
    getSelectedTime(e) {
        this.targetHour = e.hour;
        if(e.hour < 10){
            this.targetHour = '0'+ e.hour
        }else{
            this.targetHour = e.hour
        }
        if(e.minute < 10){
            this.targetMinute = '0' + e.minute
        }else{
            this.targetMinute = e.minute
        }
        this.dataWrapper.time = this.targetHour + ':' + this.targetMinute
    },
    //提交，将已修改或新增的数据传回去
    submit() {
        this.getRepeat();
        console.log(JSON.stringify(this.dataWrapper));
        router.replace({
            uri: 'pages/time/time',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        });
    },
    //删除
    remove() {
        //判断是新增进来的还是修改进来的
        if (this.dataWrapper.mode === "addAlarm") {
            this.dataWrapper.mode = ''
            router.replace({
                uri: 'pages/time/time',
                params: {
                    dataWrapper: this.dataWrapper,
                    originData: this.originData
                }
            });
        } else {
            this.dataWrapper.mode = 'deleteAlarm'
            console.log(JSON.stringify(this.dataWrapper));
            router.replace({
                uri: 'pages/time/time',
                params: {
                    dataWrapper: this.dataWrapper,
                    originData: this.originData
                }
            });
        }
    },
    //无操作退出
    back() {
        this.dataWrapper.mode = 'back'
        router.replace({
            uri: 'pages/time/time',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        })
    },
    //根据界面选择的星期情况获得星期字符串
    getRepeat(){
        let repeat = '';
        for (var index = 0; index < this.Weeks.length; index++) {
            if(this.Weeks[index].weekOn){
                repeat = repeat + this.Weeks[index].week + ' ';
            }
        }
        if(repeat == ''){
            repeat = '不重复';
        }
        this.dataWrapper.repeat = repeat;
    }
}