import router from '@system.router';
import app from '@system.app';
export default {
    data: {
        weeks: ["一", "二", "三", "四", "五", "六", "日"],
        curTime: "",
        curDay: "",
        alarm:[
            {time:'07:20',repeat:'一 二 三 四 五',switchStatus:false},
            {time:'08:20',repeat:'一 二 三 四 五',switchStatus:false},
            {time:'13:00',repeat:'日 一 二 三 四 五 六',switchStatus:false},
            {time:'18:00',repeat:'不重复',switchStatus:false}
        ],
        dataWrapper: {
            mode: "",
            time: "00:00",
            repeat: "不重复",
            switchStatus:false,
            alarmItemIndex: -1
        },
        interValId: "",
        originData:[]
    },
    //初始化
    onInit(){
        //开始计时
        this.startTimer()
        //判断是那种方式回来的
        switch (this.dataWrapper.mode) {
            case 'addAlarm':
                this.alarm = this.originData;//同步数据
            //把新增的闹钟加进去
                this.alarm.push({time:this.dataWrapper.time,repeat:this.dataWrapper.repeat,switchStatus:this.dataWrapper.switchStatus});
                break;
            case 'editAlarm':
                this.alarm = this.originData;//同步数据
            //同步修改的值
                this.alarm[this.dataWrapper.alarmItemIndex].time = this.dataWrapper.time;
                this.alarm[this.dataWrapper.alarmItemIndex].repeat = this.dataWrapper.repeat;
                this.alarm[this.dataWrapper.alarmItemIndex].switchStatus = this.dataWrapper.switchStatus;
                break;
            case 'deleteAlarm':
                this.alarm = this.originData;//同步数据
            //删除对应位置的闹钟
                this.alarm.splice(this.dataWrapper.alarmItemIndex,1);
                break;
            case 'back':
                this.alarm = this.originData;//同步数据
                break;
            default:
                break;
        }
    },
    back(e){
        app.terminate()
    },
    //设置计时函数
    setCurTime() {
        var date = new Date();
        var strHour = date.getHours() + "";
        var strMin = date.getMinutes() + "";
        var strSecond = date.getSeconds() + "";
        var strDay = date.getDay() + "";
        if (strHour.length == 1) {
            strHour = "0" + strHour;
        }
        if (strMin.length == 1) {
            strMin = "0" + strMin;
        }
        if (strSecond.length == 1) {
            strSecond = "0" + strSecond;
        }
        this.curTime = strHour + " : " + strMin + " : " + strSecond;
        this.curDay = "星期" + this.weeks[Number(strDay) - 1];
    },
    startTimer: function() {
        var intervalTime = 1000;
        this.setCurTime();
        this.interValId = setInterval(() => {
            this.setCurTime();
        }, intervalTime);
    },
    //新增闹钟
    addAlarm(e){
        this.dataWrapper.mode = 'addAlarm';//通过不同的标志判断是什么操作
        var date = new Date();
        var strHour = date.getHours();
        var strMin = date.getMinutes();
        this.dataWrapper.time = strHour + ":" + strMin;
        console.log(JSON.stringify(this.dataWrapper));
        this.originData = this.alarm;//同步数据
        //路由到editAlarm页面通过传递对象参数将2边数据同步
        router.replace({
            uri: 'pages/editAlarm/editAlarm',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        });
        clearInterval(this.interValId);
    },
    //修改闹钟
    switchToEditAlarm(index) {
        this.dataWrapper.mode = 'editAlarm';
        this.dataWrapper.time = this.alarm[index].time;
        this.dataWrapper.repeat = this.alarm[index].repeat;
        this.dataWrapper.switchStatus = this.alarm[index].switchStatus;
        this.dataWrapper.alarmItemIndex = index;
        console.log(JSON.stringify(this.dataWrapper));
        this.originData = this.alarm;//同步数据
        router.replace({
            uri: 'pages/editAlarm/editAlarm',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        });
        clearInterval(this.interValId);
    },
    //选择修改
    switchChange(index,e){
        let _this = this;
        _this.alarm[index].switchStatus = e.checked;
        if(e.checked){
            _this.dataWrapper.mode = 'back';
            setTimeout(function() {
                _this.dataWrapper.time = _this.alarm[index].time;
                _this.originData = _this.alarm;//同步数据
                router.replace({
                    uri: 'pages/timeArrive/timeArrive',
                    params: {
                        dataWrapper: _this.dataWrapper,
                        originData: _this.originData
                    }
                });
                clearInterval(this.interValId);
            }, 2000);
        }
    },
    onDestroy(){
        clearInterval(this.interValId);
    }
}