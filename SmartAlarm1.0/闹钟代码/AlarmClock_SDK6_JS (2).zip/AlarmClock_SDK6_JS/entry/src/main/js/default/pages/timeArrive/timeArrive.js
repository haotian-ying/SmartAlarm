import router from "@system.router"
export default {
    data: {
        amOrPm: "",
        dataWrapper: {
            mode: "",
            time: "00:00",
            repeat: "不重复",
            switchStatus:false,
            alarmItemIndex: -1
        },
        originData: [],
        imageFrames: [
            {
                src: "/common/A016_017.png"
            },
            {
                src: "/common/A016_018.png"
            },
            {
                src: "/common/A016_019.png"
            },
            {
                src: "/common/A016_020.png"
            },
            {
                src: "/common/A016_021.png"
            },
        ]
    },
    onInit() {
        this.dataWrapper = this.dataWrapper;
    },
    postpone() {
        router.replace({
            uri: 'pages/time/time',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        });
    },
    cancel() {
        router.replace({
            uri: 'pages/time/time',
            params: {
                dataWrapper: this.dataWrapper,
                originData: this.originData
            }
        });
    }
}