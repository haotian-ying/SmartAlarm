/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml?entry":
/*!****************************************************************************************!*\
  !*** D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml?entry ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/template.js!./time.hml */ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/style.js!./time.css */ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/script.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/resource-reference-script.js!./time.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.js")

$app_define$('@app-component/time', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/time',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.css":
/*!***************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.css ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "width": "1000px",
    "height": "480px",
    "alignItems": "center",
    "flexDirection": "column"
  },
  ".container-up": {
    "width": "1000px",
    "height": "1000px",
    "flexDirection": "row"
  },
  ".container-down": {
    "width": "1000px",
    "height": "1000px",
    "flexDirection": "column",
    "justifyContent": "flex-end",
    "alignItems": "flex-start"
  },
  ".title": {
    "fontSize": "38px",
    "textAlign": "center",
    "width": "100%",
    "marginTop": "10px",
    "marginRight": "10px",
    "marginBottom": "10px",
    "marginLeft": "10px"
  },
  ".container-title": {
    "width": "320px",
    "height": "80px",
    "justifyContent": "flex-start"
  },
  ".back-img": {
    "width": "35px",
    "height": "35px"
  },
  ".add-img": {
    "width": "35px",
    "height": "35px"
  },
  ".container-curTime": {
    "width": "320px",
    "height": "380px",
    "alignItems": "center",
    "flexDirection": "column"
  },
  ".itemWidth": {
    "width": "500px",
    "height": "200px"
  },
  ".itemDiv": {
    "width": "400px",
    "height": "100px",
    "flexDirection": "column",
    "alignItems": "center"
  },
  ".itemDiv-right": {
    "width": "120px",
    "height": "89px",
    "justifyContent": "center",
    "alignItems": "center"
  },
  ".itemText": {
    "width": "326px",
    "height": "80px"
  },
  ".switchStyle": {
    "width": "120px",
    "height": "89px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml":
/*!******************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.hml ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/time/time:1",
    "className": "container"
  },
  "type": "stack",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/time/time:2",
        "className": "container-up"
      },
      "type": "div",
      "classList": [
        "container-up"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/time/time:3",
            "className": "container-title"
          },
          "type": "div",
          "classList": [
            "container-title"
          ],
          "onBubbleEvents": {
            "click": "back"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/time/time:4"
              },
              "type": "div",
              "style": {
                "width": "360px",
                "height": "100px",
                "alignItems": "center",
                "marginLeft": "39px"
              },
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/time/time:5",
                    "src": "common/images/back.jpg",
                    "className": "back-img"
                  },
                  "type": "image",
                  "classList": [
                    "back-img"
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/time/time:10",
        "className": "container"
      },
      "type": "div",
      "classList": [
        "container"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/time/time:12",
            "className": "container-curTime"
          },
          "type": "div",
          "classList": [
            "container-curTime"
          ],
          "style": {
            "marginLeft": "30px",
            "marginTop": "70px"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/time/time:15",
                "value": function () {return this.curTime}
              },
              "type": "text",
              "style": {
                "fontSize": "28px"
              }
            },
            {
              "attr": {
                "debugLine": "pages/time/time:16",
                "value": function () {return this.curDay}
              },
              "type": "text",
              "style": {
                "fontSize": "18px"
              }
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/time/time:18",
            "className": "container-down"
          },
          "type": "div",
          "classList": [
            "container-down"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/time/time:19",
                "className": "itemWidth"
              },
              "type": "list",
              "style": {
                "height": "400px",
                "alignItems": "center"
              },
              "classList": [
                "itemWidth"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/time/time:20",
                    "type": "listItem"
                  },
                  "type": "list-item",
                  "repeat": function () {return this.alarm},
                  "style": {
                    "width": "650px",
                    "height": "89px"
                  },
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/time/time:25",
                        "className": "itemDiv"
                      },
                      "type": "div",
                      "classList": [
                        "itemDiv"
                      ],
                      "onBubbleEvents": {
                        "click": function (evt) {this.switchToEditAlarm(this.$idx,evt)}
                      },
                      "children": [
                        {
                          "attr": {
                            "debugLine": "pages/time/time:27",
                            "className": "itemText",
                            "value": function () {return this.alarm[this.$idx].time}
                          },
                          "type": "text",
                          "classList": [
                            "itemText"
                          ],
                          "style": {
                            "fontSize": "30px",
                            "marginLeft": "40px"
                          }
                        },
                        {
                          "attr": {
                            "debugLine": "pages/time/time:32",
                            "className": "itemText",
                            "value": function () {return this.alarm[this.$idx].repeat}
                          },
                          "type": "text",
                          "classList": [
                            "itemText"
                          ],
                          "style": {
                            "fontSize": "22px",
                            "color": "#a9a9a9",
                            "marginLeft": "40px"
                          }
                        }
                      ]
                    },
                    {
                      "attr": {
                        "debugLine": "pages/time/time:36",
                        "className": "itemDiv-right"
                      },
                      "type": "div",
                      "classList": [
                        "itemDiv-right"
                      ],
                      "children": [
                        {
                          "attr": {
                            "debugLine": "pages/time/time:37",
                            "checked": function () {return this.alarm[this.$idx].switchStatus},
                            "className": "switchStyle"
                          },
                          "type": "switch",
                          "classList": [
                            "switchStyle"
                          ],
                          "events": {
                            "change": function (evt) {this.switchChange(this.$idx,evt)}
                          }
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/time/time:46"
          },
          "type": "div",
          "style": {
            "width": "360px",
            "height": "100px",
            "alignItems": "center",
            "marginLeft": "100px"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/time/time:47",
                "src": "common/images/add_alarm.jpg",
                "className": "add-img"
              },
              "type": "image",
              "classList": [
                "add-img"
              ],
              "onBubbleEvents": {
                "click": "addAlarm"
              }
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/time/time:51",
            "type": "button",
            "className": "btn",
            "value": "开启自动唤醒"
          },
          "type": "input",
          "classList": [
            "btn"
          ]
        }
      ]
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.js":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/time/time.js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _newArrowCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/newArrowCheck */ "./node_modules/@babel/runtime/helpers/newArrowCheck.js"));

var _system = _interopRequireDefault(requireModule("@system.router"));

var _system2 = _interopRequireDefault(requireModule("@system.app"));

var _default = {
  data: {
    weeks: ["一", "二", "三", "四", "五", "六", "日"],
    curTime: "",
    curDay: "",
    alarm: [{
      time: '07:20',
      repeat: '一 二 三 四 五',
      switchStatus: false
    }, {
      time: '08:20',
      repeat: '一 二 三 四 五',
      switchStatus: false
    }, {
      time: '13:00',
      repeat: '日 一 二 三 四 五 六',
      switchStatus: false
    }, {
      time: '18:00',
      repeat: '不重复',
      switchStatus: false
    }],
    dataWrapper: {
      mode: "",
      time: "00:00",
      repeat: "不重复",
      switchStatus: false,
      alarmItemIndex: -1
    },
    interValId: "",
    originData: []
  },
  onInit: function onInit() {
    this.startTimer();

    switch (this.dataWrapper.mode) {
      case 'addAlarm':
        this.alarm = this.originData;
        this.alarm.push({
          time: this.dataWrapper.time,
          repeat: this.dataWrapper.repeat,
          switchStatus: this.dataWrapper.switchStatus
        });
        break;

      case 'editAlarm':
        this.alarm = this.originData;
        this.alarm[this.dataWrapper.alarmItemIndex].time = this.dataWrapper.time;
        this.alarm[this.dataWrapper.alarmItemIndex].repeat = this.dataWrapper.repeat;
        this.alarm[this.dataWrapper.alarmItemIndex].switchStatus = this.dataWrapper.switchStatus;
        break;

      case 'deleteAlarm':
        this.alarm = this.originData;
        this.alarm.splice(this.dataWrapper.alarmItemIndex, 1);
        break;

      case 'back':
        this.alarm = this.originData;
        break;

      default:
        break;
    }
  },
  back: function back(e) {
    _system2["default"].terminate();
  },
  setCurTime: function setCurTime() {
    var date = new Date();
    var strHour = date.getHours() + "";
    var strMin = date.getMinutes() + "";
    var strSecond = date.getSeconds() + "";
    var strDay = date.getDay() + "";

    if (strHour.length == 1) {
      strHour = "0" + strHour;
    }

    if (strMin.length == 1) {
      strMin = "0" + strMin;
    }

    if (strSecond.length == 1) {
      strSecond = "0" + strSecond;
    }

    this.curTime = strHour + " : " + strMin + " : " + strSecond;
    this.curDay = "星期" + this.weeks[Number(strDay) - 1];
  },
  startTimer: function startTimer() {
    var _this2 = this;

    var intervalTime = 1000;
    this.setCurTime();
    this.interValId = setInterval(function () {
      (0, _newArrowCheck2["default"])(this, _this2);
      this.setCurTime();
    }.bind(this), intervalTime);
  },
  addAlarm: function addAlarm(e) {
    this.dataWrapper.mode = 'addAlarm';
    var date = new Date();
    var strHour = date.getHours();
    var strMin = date.getMinutes();
    this.dataWrapper.time = strHour + ":" + strMin;
    console.log(JSON.stringify(this.dataWrapper));
    this.originData = this.alarm;

    _system["default"].replace({
      uri: 'pages/editAlarm/editAlarm',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });

    clearInterval(this.interValId);
  },
  switchToEditAlarm: function switchToEditAlarm(index) {
    this.dataWrapper.mode = 'editAlarm';
    this.dataWrapper.time = this.alarm[index].time;
    this.dataWrapper.repeat = this.alarm[index].repeat;
    this.dataWrapper.switchStatus = this.alarm[index].switchStatus;
    this.dataWrapper.alarmItemIndex = index;
    console.log(JSON.stringify(this.dataWrapper));
    this.originData = this.alarm;

    _system["default"].replace({
      uri: 'pages/editAlarm/editAlarm',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });

    clearInterval(this.interValId);
  },
  switchChange: function switchChange(index, e) {
    var _this = this;

    _this.alarm[index].switchStatus = e.checked;

    if (e.checked) {
      _this.dataWrapper.mode = 'back';
      setTimeout(function () {
        _this.dataWrapper.time = _this.alarm[index].time;
        _this.originData = _this.alarm;

        _system["default"].replace({
          uri: 'pages/timeArrive/timeArrive',
          params: {
            dataWrapper: _this.dataWrapper,
            originData: _this.originData
          }
        });

        clearInterval(this.interValId);
      }, 2000);
    }
  },
  onDestroy: function onDestroy() {
    clearInterval(this.interValId);
  }
};
exports["default"] = _default;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}

var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/newArrowCheck.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/newArrowCheck.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _newArrowCheck(innerThis, boundThis) {
  if (innerThis !== boundThis) {
    throw new TypeError("Cannot instantiate an arrow function");
  }
}

module.exports = _newArrowCheck;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}


/***/ })

/******/ });
//# sourceMappingURL=time.js.map