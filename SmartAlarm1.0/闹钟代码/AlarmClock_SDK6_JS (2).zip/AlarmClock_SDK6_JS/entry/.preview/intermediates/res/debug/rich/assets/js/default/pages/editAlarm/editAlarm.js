/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml?entry":
/*!**************************************************************************************************!*\
  !*** D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml?entry ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/template.js!./editAlarm.hml */ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/style.js!./editAlarm.css */ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/script.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/resource-reference-script.js!./editAlarm.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.js")

$app_define$('@app-component/editAlarm', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/editAlarm',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.css":
/*!*************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.css ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "width": "800px",
    "height": "480px",
    "flexDirection": "column"
  },
  ".container-content": {
    "width": "286px",
    "height": "230px",
    "alignContent": "center"
  },
  ".container-left": {
    "width": "370px",
    "height": "480px",
    "flexDirection": "column"
  },
  ".container-title": {
    "width": "300px",
    "height": "80px",
    "justifyContent": "flex-start"
  },
  ".button": {
    "width": "288px",
    "height": "150px"
  },
  ".back-img": {
    "width": "35px",
    "height": "35px"
  },
  ".container-right": {
    "width": "600px",
    "height": "1000px",
    "flexDirection": "column"
  },
  ".divWeek": {
    "width": "320px",
    "height": "100px",
    "justifyContent": "center",
    "alignItems": "center"
  },
  ".imgWeek": {
    "width": "40px",
    "height": "40px"
  },
  ".itemWidth": {
    "width": "960px"
  },
  ".itemDiv": {
    "width": "800px",
    "height": "150px",
    "justifyContent": "flex-end"
  },
  ".itemLeft": {
    "width": "700px",
    "height": "130px",
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center"
  },
  ".textLarger": {
    "width": "272px",
    "height": "50px",
    "fontSize": "38px",
    "textAlign": "center"
  },
  ".textStandard": {
    "width": "105px",
    "height": "40px",
    "fontSize": "30px",
    "color": "#a9a9a9",
    "textAlign": "center"
  },
  ".textLargeDiv": {
    "width": "120px",
    "height": "70px",
    "alignItems": "flex-end"
  },
  ".textMiniDiv": {
    "width": "70px",
    "height": "60px",
    "alignItems": "flex-start"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml":
/*!****************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.hml ***!
  \****************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/editAlarm/editAlarm:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/editAlarm/editAlarm:2",
        "className": "container-left"
      },
      "type": "div",
      "classList": [
        "container-left"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/editAlarm/editAlarm:3",
            "className": "container-title"
          },
          "type": "div",
          "classList": [
            "container-title"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/editAlarm/editAlarm:4"
              },
              "type": "div",
              "style": {
                "width": "280px",
                "height": "80px",
                "alignItems": "center",
                "marginLeft": "39px"
              },
              "onBubbleEvents": {
                "click": "back"
              },
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/editAlarm/editAlarm:5",
                    "src": "common/images/back.jpg",
                    "className": "back-img"
                  },
                  "type": "image",
                  "classList": [
                    "back-img"
                  ]
                },
                {
                  "attr": {
                    "debugLine": "pages/editAlarm/editAlarm:6",
                    "value": "编辑闹钟"
                  },
                  "type": "text",
                  "style": {
                    "fontSize": "38px",
                    "marginLeft": "27px"
                  }
                }
              ]
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/editAlarm/editAlarm:11",
            "className": "container-content"
          },
          "type": "div",
          "classList": [
            "container-content"
          ],
          "style": {
            "marginLeft": "40px",
            "marginTop": "45px",
            "alignItems": "center"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/editAlarm/editAlarm:12",
                "type": "time",
                "selected": function () {return this.dataWrapper.time}
              },
              "type": "picker-view",
              "style": {
                "width": "250px",
                "height": "160px",
                "fontSize": "30px",
                "selectedFontSize": "42px",
                "marginLeft": "20px"
              },
              "events": {
                "change": "getSelectedTime"
              }
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/editAlarm/editAlarm:17",
        "className": "container-right"
      },
      "type": "div",
      "classList": [
        "container-right"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/editAlarm/editAlarm:19",
            "className": "container-content"
          },
          "type": "div",
          "classList": [
            "container-content"
          ],
          "style": {
            "width": "470px",
            "marginLeft": "10px",
            "marginTop": "45px",
            "flexDirection": "column"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/editAlarm/editAlarm:20",
                "className": "divWeek"
              },
              "type": "div",
              "classList": [
                "divWeek"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/editAlarm/editAlarm:21"
                  },
                  "type": "stack",
                  "style": {
                    "width": "400px",
                    "height": "150px"
                  },
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:22",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "日"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "30px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(0,evt)}
                      }
                    },
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:24",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "一"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "70px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(1,evt)}
                      }
                    },
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:26",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "二"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "110px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(2,evt)}
                      }
                    }
                  ]
                }
              ]
            },
            {
              "attr": {
                "debugLine": "pages/editAlarm/editAlarm:42",
                "className": "divWeek"
              },
              "type": "div",
              "classList": [
                "divWeek"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/editAlarm/editAlarm:43"
                  },
                  "type": "stack",
                  "style": {
                    "width": "420px",
                    "height": "150px"
                  },
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:44",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "三"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "15px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(3,evt)}
                      }
                    },
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:46",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "四"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "55px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(4,evt)}
                      }
                    },
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:48",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "五"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "95px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(5,evt)}
                      }
                    },
                    {
                      "attr": {
                        "debugLine": "pages/editAlarm/editAlarm:50",
                        "type": "button",
                        "className": "imgWeek",
                        "value": "六"
                      },
                      "type": "input",
                      "classList": [
                        "imgWeek"
                      ],
                      "style": {
                        "left": "135px",
                        "top": "35px"
                      },
                      "onBubbleEvents": {
                        "click": function (evt) {this.changeWeekSelected(6,evt)}
                      }
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/editAlarm/editAlarm:73",
        "type": "button",
        "className": "button",
        "value": function () {return this.buttonInfo}
      },
      "type": "input",
      "classList": [
        "button"
      ],
      "style": {
        "marginTop": "40px",
        "marginLeft": "40px",
        "color": "#E42B2B"
      },
      "onBubbleEvents": {
        "click": "remove"
      }
    },
    {
      "attr": {
        "debugLine": "pages/editAlarm/editAlarm:75",
        "type": "button",
        "className": "button",
        "value": "确认"
      },
      "type": "input",
      "classList": [
        "button"
      ],
      "style": {
        "marginTop": "40px",
        "marginLeft": "40px"
      },
      "onBubbleEvents": {
        "click": "submit"
      }
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/editAlarm/editAlarm.js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault(requireModule("@system.router"));

var _default = {
  data: {
    buttonInfo: "删除闹钟",
    weekImgSrcOn: 'common/ic_clock_btn_on.png',
    weekImgSrcOff: 'common/ic_clock_btn_off.png',
    Weeks: [{
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '日'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '一'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '二'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '三'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '四'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '五'
    }, {
      weekImg: 'common/ic_clock_btn_off.png',
      weekOn: false,
      week: '六'
    }],
    dataWrapper: {
      mode: "",
      time: "00:00",
      repeat: "不重复",
      switchStatus: false,
      alarmItemIndex: -1
    },
    targetHour: "00",
    targetMinute: "00",
    targeRepeat: '不重复',
    originData: []
  },
  onInit: function onInit() {
    if (this.dataWrapper.mode === "addAlarm") {
      this.buttonInfo = "取消";
    }

    if (this.dataWrapper.mode === "editAlarm") {
      for (var i = 0; i < this.Weeks.length; i++) {
        if (this.dataWrapper.repeat.indexOf(this.Weeks[i].week) !== -1) {
          this.Weeks[i].weekOn = true;
          this.Weeks[i].weekImg = this.weekImgSrcOn;
        }
      }
    }
  },
  changeWeekSelected: function changeWeekSelected(index) {
    this.Weeks[index].weekOn = this.Weeks[index].weekOn ? false : true;
    this.Weeks[index].weekImg = this.Weeks[index].weekOn ? this.weekImgSrcOn : this.weekImgSrcOff;
  },
  getSelectedTime: function getSelectedTime(e) {
    this.targetHour = e.hour;

    if (e.hour < 10) {
      this.targetHour = '0' + e.hour;
    } else {
      this.targetHour = e.hour;
    }

    if (e.minute < 10) {
      this.targetMinute = '0' + e.minute;
    } else {
      this.targetMinute = e.minute;
    }

    this.dataWrapper.time = this.targetHour + ':' + this.targetMinute;
  },
  submit: function submit() {
    this.getRepeat();
    console.log(JSON.stringify(this.dataWrapper));

    _system["default"].replace({
      uri: 'pages/time/time',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });
  },
  remove: function remove() {
    if (this.dataWrapper.mode === "addAlarm") {
      this.dataWrapper.mode = '';

      _system["default"].replace({
        uri: 'pages/time/time',
        params: {
          dataWrapper: this.dataWrapper,
          originData: this.originData
        }
      });
    } else {
      this.dataWrapper.mode = 'deleteAlarm';
      console.log(JSON.stringify(this.dataWrapper));

      _system["default"].replace({
        uri: 'pages/time/time',
        params: {
          dataWrapper: this.dataWrapper,
          originData: this.originData
        }
      });
    }
  },
  back: function back() {
    this.dataWrapper.mode = 'back';

    _system["default"].replace({
      uri: 'pages/time/time',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });
  },
  getRepeat: function getRepeat() {
    var repeat = '';

    for (var index = 0; index < this.Weeks.length; index++) {
      if (this.Weeks[index].weekOn) {
        repeat = repeat + this.Weeks[index].week + ' ';
      }
    }

    if (repeat == '') {
      repeat = '不重复';
    }

    this.dataWrapper.repeat = repeat;
  }
};
exports["default"] = _default;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}

var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}


/***/ })

/******/ });
//# sourceMappingURL=editAlarm.js.map