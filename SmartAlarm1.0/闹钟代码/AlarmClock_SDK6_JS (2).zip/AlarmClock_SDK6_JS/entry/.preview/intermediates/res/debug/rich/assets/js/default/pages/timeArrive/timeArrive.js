/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml?entry":
/*!****************************************************************************************************!*\
  !*** D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml?entry ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/template.js!./timeArrive.hml */ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/json.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/style.js!./timeArrive.css */ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/script.js!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!../../../../../../../../../HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/lib/resource-reference-script.js!./timeArrive.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.js")

$app_define$('@app-component/timeArrive', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/timeArrive',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.css":
/*!***************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.css ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "width": "800px",
    "height": "480px",
    "borderTopWidth": "1px",
    "borderRightWidth": "1px",
    "borderBottomWidth": "1px",
    "borderLeftWidth": "1px",
    "flexDirection": "column",
    "alignItems": "center"
  },
  ".item": {
    "width": "480px",
    "height": "150px",
    "justifyContent": "center",
    "alignItems": "center"
  },
  ".imgStyle": {
    "width": "93px",
    "height": "93px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml":
/*!******************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.hml ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/timeArrive/timeArrive:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/timeArrive/timeArrive:2",
        "className": "item"
      },
      "type": "div",
      "classList": [
        "item"
      ],
      "style": {
        "flexDirection": "column"
      },
      "children": [
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:3",
            "images": function () {return this.imageFrames},
            "duration": "300ms"
          },
          "type": "image-animator",
          "style": {
            "width": "50px",
            "height": "50px"
          }
        },
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:8",
            "value": "闹钟"
          },
          "type": "text",
          "style": {
            "width": "100px",
            "height": "50px",
            "marginLeft": "45px"
          }
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/timeArrive/timeArrive:12",
        "className": "item"
      },
      "type": "div",
      "classList": [
        "item"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:14",
            "value": function () {return this.dataWrapper.time}
          },
          "type": "text",
          "style": {
            "width": "230px",
            "height": "120px",
            "fontSize": "78px",
            "textAlign": "center"
          }
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/timeArrive/timeArrive:17",
        "className": "item"
      },
      "type": "div",
      "classList": [
        "item"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:19",
            "type": "button",
            "className": "imgStyle",
            "value": "取消"
          },
          "type": "input",
          "classList": [
            "imgStyle"
          ],
          "onBubbleEvents": {
            "click": "cancel"
          }
        },
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:20"
          },
          "type": "div",
          "style": {
            "width": "50px",
            "height": "50px"
          }
        },
        {
          "attr": {
            "debugLine": "pages/timeArrive/timeArrive:27",
            "type": "button",
            "className": "imgStyle",
            "value": "推迟"
          },
          "type": "input",
          "classList": [
            "imgStyle"
          ],
          "onBubbleEvents": {
            "click": "postpone"
          }
        }
      ]
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\HarmonyOS\\hmscore\\2.2.0\\js\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!../../../../../../Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.js":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/HarmonyOS/hmscore/2.2.0/js/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./lib/resource-reference-script.js!D:/Huawei/AlarmClock_SDK6_JS/entry/src/main/js/default/pages/timeArrive/timeArrive.js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault(requireModule("@system.router"));

var _default = {
  data: {
    amOrPm: "",
    dataWrapper: {
      mode: "",
      time: "00:00",
      repeat: "不重复",
      switchStatus: false,
      alarmItemIndex: -1
    },
    originData: [],
    imageFrames: [{
      src: "/common/A016_017.png"
    }, {
      src: "/common/A016_018.png"
    }, {
      src: "/common/A016_019.png"
    }, {
      src: "/common/A016_020.png"
    }, {
      src: "/common/A016_021.png"
    }]
  },
  onInit: function onInit() {
    this.dataWrapper = this.dataWrapper;
  },
  postpone: function postpone() {
    _system["default"].replace({
      uri: 'pages/time/time',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });
  },
  cancel: function cancel() {
    _system["default"].replace({
      uri: 'pages/time/time',
      params: {
        dataWrapper: this.dataWrapper,
        originData: this.originData
      }
    });
  }
};
exports["default"] = _default;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}

var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

function requireModule(moduleName) {
  const systemList = ['system.router', 'system.app', 'system.prompt', 'system.configuration',
  'system.image', 'system.device', 'system.mediaquery', 'ohos.animator', 'system.grid', 'system.resource']
  var target = ''
  if (systemList.includes(moduleName.replace('@', ''))) {
    target = $app_require$('@app-module/' + moduleName.substring(1));
    return target;
  }
  var shortName = moduleName.replace(/@[^.]+.([^.]+)/, '$1');
  if (typeof ohosplugin !== 'undefined' && /@ohos/.test(moduleName)) {
    target = ohosplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  if (typeof systemplugin !== 'undefined') {
    target = systemplugin;
    for (let key of shortName.split('.')) {
      target = target[key];
      if(!target) {
        break;
      }
    }
    if (typeof target !== 'undefined') {
      return target;
    }
  }
  target = requireNapi(shortName);
  return target;
}


/***/ })

/******/ });
//# sourceMappingURL=timeArrive.js.map